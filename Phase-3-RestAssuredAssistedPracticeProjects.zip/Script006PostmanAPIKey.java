package restassuredScripts;

import org.testng.annotations.Test;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;

public class Script006PostmanAPIKey {

	@Test(priority='1')
	public void postmangetreq()
	{
		String PMapikey = "PMAK-65447d9b5293fb0031458e76-12647ad547b52e0b855f5fcee92aa5c181";
		given().baseUri("https://api.postman.com")
		.basePath("/workspaces")
		.header("x-api-key", PMapikey)
		.when().get()
		.then().statusCode(200).log().all();
		
		
	}
	
	
	@Test(priority='2')
	public void extract_value_response()
	{
		String PMapikey = "PMAK-65447d9b5293fb0031458e76-12647ad547b52e0b855f5fcee92aa5c181";
		
		String responseoutput = given().baseUri("https://api.postman.com")
		.basePath("/workspaces")
		.header("x-api-key", PMapikey)
		.when().get()
		.then()
		.extract().path("workspaces[0].name"); // extracting the name and save it in a string
		
		System.out.println("The name of the workspace extracted is: " + responseoutput);
		
	}
	
	
	

	@Test(priority='3')
	public void extract_response_JSONPath()
	{
		String PMapikey = "PMAK-65447d9b5293fb0031458e76-12647ad547b52e0b855f5fcee92aa5c181";
		
		Response res = given().baseUri("https://api.postman.com")
		.basePath("/workspaces")
		.header("x-api-key", PMapikey)
		.when().get()
		.then()
		.extract().response(); // extracting the response and save it in a Response object
		
		JsonPath json = new JsonPath(res.asString());
		
		System.out.println(json.getString("workspaces[0]"));
		
	}

}
