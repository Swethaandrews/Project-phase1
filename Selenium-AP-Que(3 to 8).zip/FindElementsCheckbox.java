package seleniumscripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class FindElementsCheckbox {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
        WebDriver driver = new ChromeDriver(); 
		
		driver.manage().window().maximize();
		
		driver.get("https://www.ironspider.ca/forms/checkradio.htm");
		
		driver.findElements(By.xpath("//input[@name='color']")).get(1).click();
		Thread.sleep(1000);
		
		driver.findElements(By.xpath("//input[@name='color']")).get(3).click();
		Thread.sleep(1000);
		
		driver.findElements(By.xpath("//input[@name='color']")).get(4).click();
		Thread.sleep(1000);

	}

}
